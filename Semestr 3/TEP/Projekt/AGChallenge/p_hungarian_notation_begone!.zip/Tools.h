#pragma once
#include  "atlstr.h"  //CString
#include  <math.h>
#include  <time.h>

#include <windows.h>

namespace Tools
{
	void show(CString text);
	void show(int val);
	void show(double val);
}; //namespace  Tools
